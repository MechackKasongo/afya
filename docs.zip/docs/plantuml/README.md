# Diagrammes PlantUML

Fichiers **`.puml`** prêts à coller dans un rapport ou à exporter en PNG/PDF/SVG.

| Fichier | Contenu |
|---------|---------|
| [CAS_UTILISATION_AFYA.puml](CAS_UTILISATION_AFYA.puml) | Cas d’utilisation (acteurs × cas par domaine) |
| [COMPOSANTS_AFYA.puml](COMPOSANTS_AFYA.puml) | Composants (BFF, 7 services, persistance, événements → audit) |
| [DEPLOIEMENT_AFYA.puml](DEPLOIEMENT_AFYA.puml) | Déploiement (navigateur, proxy, conteneurs, données, bus) |
| [MODELE_DOMAINE_AFYA.puml](MODELE_DOMAINE_AFYA.puml) | Modèle du domaine conceptuel par contexte délimité (7 services) |
| [CLASSES_PARTICIPANTES_AFYA.puml](CLASSES_PARTICIPANTES_AFYA.puml) | Classes participantes analyse : frontière, contrôle, entité par acteur |

### Diagrammes d'activité

| Fichier | Cas métier |
|---------|------------|
| [ACTIVITE_AUTHENTIFICATION_AFYA.puml](ACTIVITE_AUTHENTIFICATION_AFYA.puml) | Login JWT (tous les acteurs) |
| [ACTIVITE_ADMISSION_PATIENT_AFYA.puml](ACTIVITE_ADMISSION_PATIENT_AFYA.puml) | Admission réceptionniste |
| [ACTIVITE_SOIN_INFIRMIER_AFYA.puml](ACTIVITE_SOIN_INFIRMIER_AFYA.puml) | Exécution prescription infirmier·ère |
| [ACTIVITE_SORTIE_TRANSFERT_AFYA.puml](ACTIVITE_SORTIE_TRANSFERT_AFYA.puml) | Sortie ou transfert médecin |

### Diagrammes de conception

| Fichier | Type |
|---------|------|
| [CONCEPTION_COUCHE_SERVICE_AFYA.puml](CONCEPTION_COUCHE_SERVICE_AFYA.puml) | Classes de conception — couches (ex. care-entry) |
| [CONCEPTION_SEQUENCE_AUTHENTIFICATION_AFYA.puml](CONCEPTION_SEQUENCE_AUTHENTIFICATION_AFYA.puml) | Séquence login |
| [CONCEPTION_SEQUENCE_ADMISSION_AFYA.puml](CONCEPTION_SEQUENCE_ADMISSION_AFYA.puml) | Séquence admission multi-services |
| [CONCEPTION_SEQUENCE_CLINICAL_AFYA.puml](CONCEPTION_SEQUENCE_CLINICAL_AFYA.puml) | Séquence prescription / administration / document |

### Diagrammes d'états (conception)

| Fichier | Agrégat |
|---------|---------|
| [ETAT_ADMISSION_AFYA.puml](ETAT_ADMISSION_AFYA.puml) | Cycle de vie `Admission` (care-entry-service) |
| [ETAT_STAY_AFYA.puml](ETAT_STAY_AFYA.puml) | Cycle de vie `Stay` / séjour (stay-service) |

## Rendu rapide

- **PlantUML VS Code / Cursor** : extension « PlantUML » (Jar Graphviz conseillé pour la mise en page).
- **Ligne de commande** : `plantuml docs/plantuml/*.puml` (voir [plantuml.com](https://plantuml.com/starting)).
- **En ligne** : [plantuml online server](http://www.plantuml.com/plantuml/) (sans données sensibles en production).

## Note

Diagramme aligné avec [../CARTOGRAPHIE_EXIGENCES.md](../CARTOGRAPHIE_EXIGENCES.md) et avec la vue Mermaid de [../DIAGRAMMES_UML.md](../DIAGRAMMES_UML.md).
