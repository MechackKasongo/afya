# Démarrage — Afya Platform (multi-services)

## Prérequis

- Java 21
- Maven (wrapper inclus : `./mvnw`)
- Podman ou Docker (base PostgreSQL)

## 1. Base identity-service

```bash
cd ~/IdeaProjects/afya
podman compose up -d
```

PostgreSQL écoute sur **localhost:5433** (base `afya_identity`, user/mot de passe `afya`).

## 2. Lancer les services

**identity-service** (port 8081) :

```bash
./mvnw -pl identity-service spring-boot:run
```

**catalog-service** (port 8082) :

```bash
./mvnw -pl catalog-service spring-boot:run
```

**patient-service** (port 8083) :

```bash
./mvnw -pl patient-service spring-boot:run
```

- Identity : **http://localhost:8081**
- Catalog : **http://localhost:8082**
- Patient : **http://localhost:8083**
- Care-entry : **http://localhost:8084**
- Stay : **http://localhost:8085**
- Clinical : **http://localhost:8086**
- Audit : **http://localhost:8087**

**care-entry-service** (nécessite patient + catalog démarrés pour les appels inter-services) :

```bash
./mvnw -pl care-entry-service spring-boot:run
```
- Santé : **http://localhost:8081/actuator/health**
- Login : `POST http://localhost:8081/api/v1/auth/login`

Compte bootstrap (premier démarrage) :

| Champ | Valeur |
|-------|--------|
| Utilisateur | `admin` |
| Mot de passe | `Admin@Afya2026!` |

Variables JWT optionnelles : `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET` (≥ 64 caractères UTF-8).

## 3. Tests

```bash
./mvnw test
```

## 4. Exemple catalog (avec JWT admin)

```bash
TOKEN=$(curl -s -X POST http://localhost:8081/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"Admin@Afya2026!"}' | jq -r .accessToken)

curl -s http://localhost:8082/api/v1/hospital-services \
  -H "Authorization: Bearer $TOKEN" | jq .
```

## 5. Exemple patient (JWT réceptionniste ou admin)

Créer un utilisateur `RECEPTION` via identity (ou utiliser admin) puis :

```bash
curl -s -X POST http://localhost:8083/api/v1/patients \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"firstName":"Jean","lastName":"Mukendi","birthDate":"1985-03-20","sex":"M"}' | jq .
```

## 6. Exemple admission

```bash
curl -s -X POST http://localhost:8084/api/v1/admissions \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"patientId":1,"hospitalServiceId":1}' | jq .
```

## 7. Exemple séjour (après admission)

```bash
curl -s -X POST http://localhost:8085/api/v1/stays \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"admissionId":1,"patientId":1,"roomLabel":"A12","bedLabel":"LIT-1"}' | jq .
```

Lors d'une **sortie** (`POST .../admissions/{id}/discharge`), care-entry appelle automatiquement la clôture du séjour.

## 8. Exemple dossier clinique

```bash
curl -s http://localhost:8086/api/v1/patients/1/medical-record \
  -H "Authorization: Bearer $TOKEN" | jq .

curl -s -X POST http://localhost:8086/api/v1/patients/1/prescriptions \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"drugName":"Paracétamol","dosage":"500mg","frequency":"3x/jour","startDate":"2026-05-15"}' | jq .
```

Les documents stockent une clé `objectStorageKey` (MinIO/S3 à brancher ultérieurement).

## 9. Audit (journal et rapports admin)

```bash
./mvnw -pl audit-service spring-boot:run
```

Ingestion (JWT utilisateur — `actorUsername` optionnel, déduit du token) :

```bash
curl -s -X POST http://localhost:8087/api/v1/audit/events \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"action":"ADMISSION_CREATED","resourceType":"ADMISSION","resourceId":"10","sourceService":"care-entry-service"}' | jq .
```

Le publisher d’audit est centralisé dans **`afya-shared`** (`AuditEventPublisher`, config auto si `app.audit.enabled`).

En dev, les services publient vers l’audit (clé `dev-audit-ingestion-key`, désactivable via `AUDIT_ENABLED=false`) :
- **identity** : `LOGIN_SUCCESS`, `LOGIN_FAILED`, `LOGOUT_SUCCESS`
- **patient** : `PATIENT_CREATED`, `PATIENT_UPDATED`, `PATIENT_CONTACTS_UPDATED`, `APPOINTMENT_CREATED`, `APPOINTMENT_CANCELLED`
- **care-entry** : `ADMISSION_CREATED`, `ADMISSION_TRANSFERRED`, `ADMISSION_DISCHARGED`, `ADMISSION_CANCELLED`, `EMERGENCY_VISIT_CREATED`, `EMERGENCY_VISIT_CLOSED`
- **stay** : `STAY_OPENED`, `STAY_CLOSED`, `HOSPITALIZATION_FORM_UPDATED`
- **clinical** : `MEDICAL_RECORD_OPENED`, `CLINICAL_NOTE_ADDED`, `DIAGNOSIS_ADDED`, `PRESCRIPTION_CREATED`, `MEDICATION_ADMINISTERED`, `NURSING_CARE_RECORDED`, `CLINICAL_DOCUMENT_ADDED`
- **catalog** (admin) : `DEPARTMENT_*`, `HOSPITAL_SERVICE_*`, `BED_CREATED`, `BED_DELETED`

Ingestion machine-à-machine (clé `AUDIT_INGESTION_KEY`, header `X-Audit-Ingestion-Key`) :

```bash
curl -s -X POST http://localhost:8087/api/v1/audit/events \
  -H "X-Audit-Ingestion-Key: $AUDIT_INGESTION_KEY" \
  -H 'Content-Type: application/json' \
  -d '{"actorUsername":"identity-job","action":"LOGIN_SUCCESS","resourceType":"USER","resourceId":"admin","sourceService":"identity-service"}' | jq .
```

Consultation (rôle **ADMIN** uniquement) :

```bash
curl -s "http://localhost:8087/api/v1/audit/events?page=0&size=20" \
  -H "Authorization: Bearer $TOKEN" | jq .

curl -s http://localhost:8087/api/v1/reports/activity \
  -H "Authorization: Bearer $TOKEN" | jq .
```

## 10. BFF (point d’entrée API pour le front)

Le module **`afya-bff`** (port **8080**) agrège auth, patients, admissions, urgences, séjours, dossier clinique (notes, diagnostics, prescriptions, soins), catalogue et rapport d’activité admin.

```bash
./mvnw -pl afya-bff spring-boot:run
```

Prérequis pour le tableau de bord : **identity**, **patient**, **catalog**, **care-entry**, **stay**, **clinical-record** (et **audit** pour le rapport admin).

Login via le BFF :

```bash
curl -s -X POST http://localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"Admin@Afya2026!"}' | jq .
```

Même secret JWT que identity : `JWT_ACCESS_SECRET` (≥ 64 caractères).

## 11. Front React (Vite)

```bash
cd frontend
npm install
npm run dev
```

- UI : **http://localhost:5173**
- En dev, Vite proxifie **`/api`** → **http://localhost:8080** (BFF)
- Build prod : `VITE_API_BASE_URL=` vide si Nginx sert UI + proxy `/api` → BFF

Compte bootstrap : `admin` / `Admin@Afya2026!`

### Nginx (prod / conteneur web)

Fichier `frontend/docker/nginx-default.conf` : `/api/` → service **`bff:8080`**, fichiers statiques pour le SPA.

## 12. Démarrage minimal (dev UI)

Terminal 1 — bases :

```bash
podman compose up -d
```

Terminaux suivants (ou un script) :

```bash
./mvnw -pl identity-service,catalog-service,patient-service,care-entry-service,audit-service,afya-bff spring-boot:run
```

Puis :

```bash
cd frontend && npm run dev
```

Voir [ARCHITECTURE_SERVICES.md](ARCHITECTURE_SERVICES.md).
